# Pin Screen | three.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/DonKarlssonSan/pen/wjJZRY](https://codepen.io/DonKarlssonSan/pen/wjJZRY).

Pin screen made with three.js and the webcam on your device. 

Works on my Mac in Safari, Chrome and Firefox.

Works on my iPhone with iOS 11 in Safari (sluggish), but not in Chrome

Works on my PC (Windows 10) in Chrome, but not in Firefox, nor Edge.

